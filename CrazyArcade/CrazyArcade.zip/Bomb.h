#pragma once
#include"pch.h"



class Bomb {
	POINT pos;
	int time;
	int state;
	int reach;
public:


};