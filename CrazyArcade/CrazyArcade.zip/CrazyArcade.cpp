﻿#include"pch.h"
#include"Board.h"
#include"Player.h"
#include"Bomb.h"
HINSTANCE g_hInst;
LPCTSTR lpszClass = L"Window Class Name";
LPCTSTR lpszWindowName = L"2025 Window Programming Exam";

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static Player p1, p2;
    static Board board[MAP_TILES][MAP_TILES];
    static int selected_stage = 0;
    switch (msg) {
    case WM_CREATE:
      
        return 0;
    case WM_KEYDOWN:
        if (wParam < 256) keyStates[wParam] = true;
        return 0;
    case WM_KEYUP:
        if (wParam < 256) keyStates[wParam] = false;
        return 0;
    case WM_TIMER: {
        float speed = 1.0f / 8.0f;
        if (selected_stage) {
            HandlePlayerMovement(p1, keyStates, 'W', 'S', 'A', 'D', board);
            UpdatePlayerPosition(p1, speed);

            HandlePlayerMovement(p2, keyStates, VK_UP, VK_DOWN, VK_LEFT, VK_RIGHT, board);
            UpdatePlayerPosition(p2, speed);
        }
        InvalidateRect(hWnd, NULL, FALSE);
        return 0;
    }
    case WM_CHAR:
        if (selected_stage == 0) {
            if (wParam == '1') {
                selected_stage = 1;
                POINT p1_start_point = { 8,18 };
                POINT p2_start_point = { 11,18 };

                p1.Init_Player(p1_start_point);
                p2.Init_Player(p2_start_point);
                init_board(board);
                SetTimer(hWnd, TIMER_ID, TIMER_INTERVAL, NULL);
            }
            else  if (wParam == '2') {
                selected_stage = 2;
            }
            else  if (wParam == '3') {
                selected_stage = 3;
            }
        }
        break;
    case WM_PAINT: {
        if (selected_stage) {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            HDC mem = CreateCompatibleDC(hdc);
            HBITMAP bmp = CreateCompatibleBitmap(hdc, WINDOW_WIDTH, WINDOW_HEIGHT);
            HGDIOBJ oldBmp = SelectObject(mem, bmp);
            RECT rc = { 0,0,WINDOW_WIDTH,WINDOW_HEIGHT };
            FillRect(mem, &rc, (HBRUSH)GetStockObject(WHITE_BRUSH));
            DrawGrid(mem, board);
            p1.Draw_Player(mem, &p1, RGB(255, 0, 255));
            p2.Draw_Player(mem, &p2, RGB(0, 255, 255));
            BitBlt(hdc, 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, mem, 0, 0, SRCCOPY);
            SelectObject(mem, oldBmp);
            DeleteObject(bmp);
            DeleteDC(mem);
            EndPaint(hWnd, &ps);
        }
        return 0;
    }
    case WM_DESTROY:
        KillTimer(hWnd, TIMER_ID);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nCmdShow) {
    WNDCLASSEX wc = { sizeof(wc) };
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WndProc;
    wc.cbClsExtra = 0; wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName = NULL;
    wc.lpszClassName = lpszClass;
    wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    RegisterClassEx(&wc);
    HWND hWnd = CreateWindow(lpszClass, lpszWindowName, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        WINDOW_WIDTH + marginX, WINDOW_HEIGHT + marginY,
        NULL, NULL, hInstance, NULL);
    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return (int)msg.wParam;
}
