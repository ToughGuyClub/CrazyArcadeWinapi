#include "Board.h"

void init_board(Board board[MAP_TILES][MAP_TILES]) {
    int mapSize = min(WINDOW_WIDTH, WINDOW_HEIGHT);
    int tile = mapSize / MAP_TILES/2;
    int ox = (WINDOW_WIDTH - mapSize) / 2;
    for (int i = 0; i < MAP_TILES; ++i) {
        for (int j = 0;j < MAP_TILES;++j) {
            board[i][j].pos.x = ox+tile + j * tile * 2;
            board[i][j].pos.y = tile + i * tile * 2;
        }
    }
    // �ϵ��ڵ��� �� ������ (0: ���, 1: �ʷϻ�, 2: �����, 3: ����)
    int obstacle_map[MAP_TILES][MAP_TILES] = {
     {0,0,1,1,0,1,0,0,0,2,2,0,0,0,1,0,1,1,0,0},
     {0,0,0,1,0,0,0,0,0,2,2,0,0,0,0,0,1,0,0,0},
     {1,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,1},
     {0,0,0,1,1,1,1,0,0,0,0,0,0,1,1,1,1,0,0,0},
     {0,0,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,0,0},
     {0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0},
     {0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0},
     {0,1,0,0,1,0,0,0,0,1,1,0,0,0,0,1,0,0,1,0},
     {1,1,1,0,1,1,1,0,0,1,1,0,0,1,1,1,0,1,1,1},
     {1,1,1,1,1,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1},
     {1,1,1,1,1,1,0,0,1,1,1,1,0,0,1,1,1,1,1,1},
     {1,0,0,0,0,1,1,0,0,1,1,0,0,1,1,0,0,0,0,1},
     {0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0},
     {0,0,1,0,0,1,0,0,0,1,1,0,0,0,1,0,0,1,0,0},
     {0,1,1,1,0,1,1,0,0,0,0,0,0,1,1,0,1,1,1,0},
     {0,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,0,0},
     {0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
     {0,0,0,0,1,0,0,1,1,1,1,1,1,0,0,1,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0},
     {1,1,0,0,0,0,0,0,3,1,1,3,0,0,0,0,0,0,1,1}
    };

    for (int i = 0; i < MAP_TILES; ++i) {
        for (int j = 0; j < MAP_TILES; ++j) {
         
            board[i][j].obstacle = obstacle_map[i][j];
        }
    }
}
void DrawGrid(HDC hdc, Board board[MAP_TILES][MAP_TILES]) {
    int mapSize = min(WINDOW_WIDTH, WINDOW_HEIGHT);
    int tile = mapSize / MAP_TILES / 2;
    int ox = (WINDOW_WIDTH - mapSize) / 2;
    int oy = (WINDOW_HEIGHT - mapSize) / 2;

    HPEN pen = CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
    HPEN oldPen = (HPEN)SelectObject(hdc, pen);

    for (int i = 0; i < MAP_TILES; ++i) {
        for (int j = 0; j < MAP_TILES; ++j) {
            COLORREF color;

            switch (board[i][j].obstacle) {
            case 0:
                color = RGB(255, 255, 255);
                break;
            case 1:  // �ʷϻ� (����)
                color = RGB(0, 255, 0);
                break;
            case 2:  // �ϴû� (��� ���� ����)
                color = RGB(255, 255, 0);
                break;
            case 3:  // ���� (�ٱ���)
                color = RGB(139, 69, 19); // ������
                break;
            default:
                color = RGB(255, 255, 255);
                break; // 0�� ��ֹ��� �׸��� ����
            }

            HBRUSH hbrush = CreateSolidBrush(color);
            HBRUSH oldbrush = (HBRUSH)SelectObject(hdc, hbrush);

            Rectangle(hdc,
                board[i][j].pos.x - tile,
                board[i][j].pos.y - tile,
                board[i][j].pos.x + tile,
                board[i][j].pos.y + tile);

            SelectObject(hdc, oldbrush);
            DeleteObject(hbrush);
        }
    }

    SelectObject(hdc, oldPen);
    DeleteObject(pen);
}
